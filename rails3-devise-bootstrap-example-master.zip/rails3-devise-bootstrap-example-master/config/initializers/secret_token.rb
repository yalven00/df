# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Myinfo::Application.config.secret_token = '3d8d1ad715bc7511ea0620a2ed35cbaed28ac05aa968c4c33bdb52c0e62eeaea3c097263c3b4a98ad402c1cf73aa1584058d770e40eb6a76a33258f7f5213545'
