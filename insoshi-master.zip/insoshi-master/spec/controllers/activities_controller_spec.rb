require File.dirname(__FILE__) + '/../spec_helper'

describe ActivitiesController do 
end